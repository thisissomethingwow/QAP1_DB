select customer_id
from rental 
group by customer_id;