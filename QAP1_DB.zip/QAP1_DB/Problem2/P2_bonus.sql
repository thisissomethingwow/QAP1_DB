select customer.first_name,customer.last_name,payment.amount
from customer
inner join payment on customer.customer_id = payment.customer_id
where payment.amount >10
group by customer.customer_id,payment.amount
order by payment.amount desc
LIMIT 10;