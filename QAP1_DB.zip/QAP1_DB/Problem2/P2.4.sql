select film_id,title,rental_rate,replacement_cost
from film
order by rental_rate desc;