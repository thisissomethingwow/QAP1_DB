select *
from payment
where amount > 10;