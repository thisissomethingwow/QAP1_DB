
create table Authors(
	author_id serial primary key,
	author_name varchar(100) not null,
	author_bio text
);

create table Books(
	book_id serial primary key,
	book_title varchar(255) not null,
	publication_year int,
	author_id int references Authors(author_id) on delete cascade
)