insert into customer (store_id,first_name,last_name,email,address_id)
values
	(1,'John','Doe','John@gmail.com',1),
	(1,'Jane','Doe','Jane@gmail.com',1),
	(1,'Jack','Doe','Jack@gmail.com',1),
	(1,'Jill','Doe','Jill@gmail.com',1);