update address
set address = 'New Place',
	city_id = 2
where address_id = 1;

update customer
set address_id = 2
where last_name = 'Doe';

update store 
set address_id = 2
where address_id = 1;