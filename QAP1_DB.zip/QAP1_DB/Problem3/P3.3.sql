delete from address
where address_id = 1;